import React from 'react'
import "../Footer/Footer.css";

export default function Footer() {
    return (
            <div className="footer">
                <h2>Foodie &copy; 2021 </h2>
            </div>
    )
}
